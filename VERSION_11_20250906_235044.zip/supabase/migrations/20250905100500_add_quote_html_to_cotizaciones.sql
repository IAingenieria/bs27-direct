ALTER TABLE public.cotizaciones
ADD COLUMN IF NOT EXISTS quote_html TEXT;
